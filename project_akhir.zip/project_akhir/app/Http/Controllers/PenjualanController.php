<?php

namespace App\Http\Controllers;

use App\Models\Penjualan;
use Illuminate\Http\Request;

class PenjualanController extends Controller
{
    function tampil() {
        $penjualan = Penjualan::all();
        return view('penjualan', compact('penjualan'));
    }

    function tambah(Request $request) {
        $request->validate([
            'kode_transaksi' => 'required|unique:penjualan,kode_transaksi',
            'tanggal_penjualan' => 'required|date',
            'harga_per_barang' => 'required|numeric',
            'jumlah_barang' => 'required|integer|min:1',
        ]);

        Penjualan::create([
            'kode_transaksi' => $request->kode_transaksi,
            'tanggal_penjualan' => $request->tanggal_penjualan,
            'harga_per_barang' => $request->harga_per_barang,
            'jumlah_barang' => $request->jumlah_barang,
            'total_harga' => $request->harga_per_barang * $request->jumlah_barang,
        ]);

        return redirect()->route('penjualan')->with('success', 'Penjualan berhasil ditambahkan.');
    }

    function edit(Request $request, Penjualan $penjualan) {
        $request->validate([
            'kode_transaksi' => 'required|unique:penjualan,kode_transaksi,' . $penjualan->id,
            'tanggal_penjualan' => 'required|date',
            'harga_per_barang' => 'required|numeric',
            'jumlah_barang' => 'required|integer|min:1',
        ]);

        $penjualan->update([
            'kode_transaksi' => $request->kode_transaksi,
            'tanggal_penjualan' => $request->tanggal_penjualan,
            'harga_per_barang' => $request->harga_per_barang,
            'jumlah_barang' => $request->jumlah_barang,
            'total_harga' => $request->harga_per_barang * $request->jumlah_barang,
        ]);

        return redirect()->route('penjualan')->with('success', 'Data penjualan berhasil diperbarui.');
    }

    function delete(Penjualan $penjualan) {
        $penjualan->delete();
        return redirect()->route('penjualan')->with('success', 'Penjualan berhasil dihapus.');
    }
}
