<?php


use App\Http\Controllers\AuthController;
use App\Http\Controllers\PenjualanController;
use App\Http\Controllers\ProdukController;
use Illuminate\Support\Facades\Route;


Route::get('/produk', [ProdukController::class, 'tampil'])->name('produk'); // Menampilkan halaman produk
Route::post('/produk/tambah', [ProdukController::class, 'tambah'])->name('produk.tambah'); // Menambahkan produk baru
Route::put('/produk/edit/{produk}', [ProdukController::class, 'edit'])->name('produk.edit'); // Mengedit data produk
Route::delete('/produk/delete/{produk}', [ProdukController::class, 'delete'])->name('produk.delete'); // Menghapus produk

Route::get('/penjualan', [PenjualanController::class, 'tampil'])->name('penjualan');
Route::post('/penjualan/tambah', [PenjualanController::class, 'tambah'])->name('penjualan.tambah');
Route::put('/penjualan/edit/{penjualan}', [PenjualanController::class, 'edit'])->name('penjualan.edit');
Route::delete('/penjualan/delete/{penjualan}', [PenjualanController::class, 'delete'])->name('penjualan.delete');

Route::get('login', [AuthController::class, 'showLoginForm'])->name('loginForm');
Route::post('login', [AuthController::class, 'login'])->name('login');